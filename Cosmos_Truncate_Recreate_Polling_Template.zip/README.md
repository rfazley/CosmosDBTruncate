
# CosmosTruncateAndRecreate_Polling – ADF Template (Polling Version)

This template replaces the fixed 30-second wait with a **polling loop** that repeatedly calls the ARM **List SQL Containers** endpoint until the target container **no longer appears** in the list, then recreates it. All calls use **Managed Identity** to `https://management.azure.com/`.

## Flow
1. **DeleteContainer** – `DELETE` ARM container.
2. **PollUntilDeleted (Until)** – Loops:
   - **ListContainers** – `GET .../containers` (always returns 200).
   - **SetIsDeleted** – Sets `isDeleted` to true when the container name is not found in the response body.
   - **Sleep5s** – Small backoff.
3. **CreateContainer** – `PUT` ARM container with partition key, indexing policy, TTL and throughput.

## Parameters
- `subscriptionId`, `resourceGroupName`, `accountName`, `databaseName`, `containerName` (required)
- `location` (default: West Europe), `partitionKeyPath` (default: /pk), `manualRU` (default: 400), `defaultTtl` (default: 0), `indexingPolicyJson` (default: lenient)

## Notes
- The polling loop uses the JSON body of `ListContainers` to detect when deletion has completed without relying on response headers.
- Increase the `Until.timeout` or adjust the `Sleep5s` wait if you expect very large containers.
- After recreate, append your Copy activity to load fresh data.
